﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input file name:");
            string input = Console.ReadLine();
            Console.WriteLine();

            try
            {
                string file = Path.GetFullPath(input);

                INameSorter iNameSorter = new NameSorter(file);
                iNameSorter.SortName();

                //looping of sorted name
                foreach (string sortedName in iNameSorter.SortName())
                {
                    Console.WriteLine(sortedName + "\n");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
            }

            Console.ReadKey();
        }

    }
}
