﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ConsoleApplication1
{
    public class NameSorter : INameSorter
    {
        private string _inputFile;
        private string _outputFile = "sorted-names-list.txt";

        public NameSorter(string inputFile)
        {
            this._inputFile = inputFile;
        }

        public List<string> SortName()
        {
            string[] inputNameArr = System.IO.File.ReadAllLines(this._inputFile);

            List<string> lsReversedName = new List<string>();

            //looping of file content
            foreach (string inputName in inputNameArr)
            {
                if (!string.IsNullOrEmpty(inputName))//validation name must not be empty
                {
                    //reverse the name
                    string reversedName = ReversedName(inputName);

                    lsReversedName.Add(reversedName);
                }
            }

            if (lsReversedName.Count > 0)
            {
                //sort the reversed name
                lsReversedName.Sort();
            }

            List<string> lsSortedName = new List<string>();

            StreamWriter writeFile = new StreamWriter(Path.GetFullPath(this._outputFile));

            //looping the sorted name by reversed
            foreach (string sortedName in lsReversedName)
            {
                //reverse again to origin name
                string originName = ReversedName(sortedName);

                //save to file
                writeFile.WriteLine(originName);
                
                lsSortedName.Add(originName);
            }

            writeFile.Close();

            return lsSortedName;
        }

        private string ReversedName(string inputName)
        {
            string[] nameArr = inputName.Split(' ').ToArray();

            string reversedName = "";

            //reverse the name
            for (int i = nameArr.Count() - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    reversedName += nameArr[i];
                }
                else
                {
                    reversedName += nameArr[i] + " ";
                }
            }

            return reversedName;
        }
    }
}
